# -*- coding:UTF-8 -*-
import src_test as st

handle = st.ZMCWrapper()

#handle.func_test()

st.test(handle)